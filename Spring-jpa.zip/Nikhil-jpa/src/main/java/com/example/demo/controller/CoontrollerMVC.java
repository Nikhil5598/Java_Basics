package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


import com.example.demo.model.Customer;

@Controller 
public class CoontrollerMVC {

	@Autowired
	CustomerRepo repo;
	@GetMapping(value="/")
	public String getHome() {
		return "home.jsp";
	}
	@PostMapping(value="/addcustomer")
	public String getCustomer(Customer data,Model model) {
		repo.save(data);
		model.addAttribute("data",repo.findAll());
		return "success.jsp";
	}
}
